Hallo liebe Tester!

Hier findet ihr eine Einleitung für unser "RoboRally"!

1. Server starten:
	
	Den Server startet ihr mit einem Doppel-Klick der server.jar. Es wird sich hier KEIN Fenster öffnen oder ähnliches. Ebenfalls darf nur ein Server gestartet werden.
	Beenden könnt ihr den Server im Task-Manager. Dort einfach den Prozess "java.exe" beenden.
	
	Entwas einfacher geht das ganze wenn ihr die JAR im CMD startet und dort dann den Prozess via Strg+C beendet.

2. Clients starten:

	Die Clients lassen sich mit einem Doppel-Klick der client.jar starten. Wenn sich dann ein Fenster mit dem Logo von RoboRally (bläulich eingefärbt) öffnet hat alles geklappt!
	Beenden könnt ihr die Clients ganz einfach wenn ihr auf das "Schließen" oben Rechts klickt (wie man das normal von Programmen kennt).

Weitere Infos:

	- Bitte benennt NICHT den Ordner "betatest" um. Das führt ansonsten zu Problemen.
	- Ihr könnt prinzipiell alles außer den JARS im "betatest"-Ordner ignorieren.
	- legt den betatest-Ordner am besten NICHT in eurem OneDrive (oder ähnlichem) ab. Das kann zu Problemen führen (JavaFX bedingt).
	- Falls nötig findet ihr in "logFiles" die erzeugten LogFiles des servers (alle benannt mit der Endung [aktuelles Datum+Zeit]serverLog.lck bzw. [aktuelles Datum+Zeit]clientLog.lck)



Wir wünschen euch viel Spaß und hoffen auf erfolgreiches Testen!

Eure edlen Eisbecher